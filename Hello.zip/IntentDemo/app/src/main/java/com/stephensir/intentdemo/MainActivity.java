package com.stephensir.intentdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    /* <!-- IntentDemo --> */
    // ==== Properties ====
    private String TAG = "MainActivity===>";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ==== Screen Management ====
        // Orientation Sensor
        // setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
        //setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_NOSENSOR);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        //setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        // Keep screen always on
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

    } //onCreate()

    // ==== Button onClick ====
    public void btnCallClick(View v){
        Log.d(TAG,"btnCallClick");
        doCall();
    }

    public void btnSearchClick(View v){
        Log.d(TAG,"btnSearchClick");
        doSearch();
    }

    public void btnMapClick(View v){
        Log.d(TAG,"btnMapClick");
        doMap();
    }

    public void btnAboutClick(View v){
        Log.d(TAG,"btnAboutClick");
        doAbout();
    }
    // ==== function ====
    private void doCall(){
        Log.d(TAG,"doCall");
        // require android.permission.CALL_PHONE permission
        // Call phone
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("tel:+12345678"));
        startActivity(intent);
    }

    private void doSearch(){
        Log.d(TAG,"doSearch");
        // require android.permission.INTERNET permission
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("http://www.google.com.hk"));
        startActivity(intent);
    }

    private void doMap(){
        Log.d(TAG,"doMap");
        // require android.permission.INTERNET permission
        Uri uri = Uri.parse("geo:22.293564,114.16952?z=19");
        //Uri uri = Uri.parse("geo:22.293564,114.16952?q=Tsim+Sha+Tsui");
        //Uri uri = Uri.parse("google.streetview:cbll=22.293564,114.16952");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        intent.setPackage("com.google.android.apps.maps");

        // pre check application available
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            Toast.makeText(this,"No google map!", Toast.LENGTH_LONG).show();
        }
    }

    private void doAbout(){
        Log.d(TAG,"doAbout");
        Toast.makeText(this,getResources().getString(R.string.msg_about), Toast.LENGTH_LONG).show();
    }
    /* <!-- IntentDemo --> */

} //MainActivity
